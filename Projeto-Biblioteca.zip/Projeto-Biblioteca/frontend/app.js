function carregarLivros() {
    fetch("http://localhost:8080/livros")
        .then(resposta => resposta.json())
        .then(livros => {
            let tabela = document.getElementById("tabelaLivros");
            tabela.innerHTML = "";

            livros.forEach(livro => {
                let linha = tabela.insertRow();

                linha.insertCell(0).textContent = livro.id;
                linha.insertCell(1).textContent = livro.titulo;
                linha.insertCell(2).textContent = livro.autor;
                linha.insertCell(3).textContent = livro.genero;
                linha.insertCell(4).textContent = livro.anoPublicacao;
                linha.insertCell(5).textContent = livro.paginas;

                // Criação dos botões dentro da última célula
                let celulaAcoes = linha.insertCell(6);

                let btnEditar = document.createElement("button");
                btnEditar.textContent = "Editar";
                btnEditar.onclick = () => editarLivro(livro);
                celulaAcoes.appendChild(btnEditar);

                let btnRemover = document.createElement("button");
                btnRemover.textContent = "Remover";
                btnRemover.onclick = () => removerLivro(livro.id);
                celulaAcoes.appendChild(btnRemover);
            });
        })
        .catch(erro => console.error("Erro ao carregar livros:", erro));
}


function cadastrarLivro() {
    let livro = {
        titulo: document.getElementById("titulo").value,
        autor: document.getElementById("autor").value,
        genero: document.getElementById("genero").value,
        anoPublicacao: parseInt(document.getElementById("anoPublicacao").value),
        paginas: parseInt(document.getElementById("paginas").value)
    };

    let id = document.getElementById("livroId").value;

    if (id) {
        // Atualizar
        fetch(`http://localhost:8080/livros/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(livro)
        }).then(() => {
            limparCampos();
            carregarLivros();
        });
    } else {
        // Cadastrar
        fetch("http://localhost:8080/livros", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(livro)
        }).then(() => {
            limparCampos();
            carregarLivros();
        });
    }
}

function removerLivro(id) {
    fetch(`http://localhost:8080/livros/${id}`, {
        method: "DELETE"
    }).then(() => carregarLivros());
}

function editarLivro(livro) {
    document.getElementById("livroId").value = livro.id;
    document.getElementById("titulo").value = livro.titulo;
    document.getElementById("autor").value = livro.autor;
    document.getElementById("genero").value = livro.genero;
    document.getElementById("anoPublicacao").value = livro.anoPublicacao;
    document.getElementById("paginas").value = livro.paginas;
}

function limparCampos() {
    document.getElementById("livroId").value = "";
    document.getElementById("titulo").value = "";
    document.getElementById("autor").value = "";
    document.getElementById("genero").value = "";
    document.getElementById("anoPublicacao").value = "";
    document.getElementById("paginas").value = "";
}




