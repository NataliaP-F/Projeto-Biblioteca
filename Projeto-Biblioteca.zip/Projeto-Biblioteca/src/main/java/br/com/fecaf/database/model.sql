CREATE DATABASE biblioteca;
USE  biblioteca;

CREATE TABLE livro (
  id BIGINT NOT NULL AUTO_INCREMENT,
  titulo VARCHAR(255),
  autor VARCHAR(255),
  genero VARCHAR(255),
  ano_publicacao INT,
  paginas INT,
  PRIMARY KEY (id)
);

SELECT * FROM livro;