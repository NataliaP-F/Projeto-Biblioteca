package br.com.fecaf.repositorio;

import br.com.fecaf.model.Livro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LivroRepositorio extends JpaRepository <Livro, Long> {
}
