package br.com.fecaf.controller;

import br.com.fecaf.model.Livro;
import br.com.fecaf.repositorio.LivroRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/livros")


public class  LivroController {
    @Autowired
    private LivroRepositorio repositorio;

    @GetMapping
    public List<Livro> listarTodos() {
        return repositorio.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Livro> buscarPorId(@PathVariable Long id) {
        return repositorio.findById(id);
    }

    @PostMapping
    public Livro adicionar(@RequestBody Livro livro) {
        return repositorio.save(livro);
    }

    @PutMapping("/{id}")
    public Livro atualizar(@PathVariable Long id, @RequestBody Livro livroAtualizado) {
        return repositorio.findById(id).map(livro -> {
            livro.setTitulo(livroAtualizado.getTitulo());
            livro.setAutor(livroAtualizado.getAutor());
            livro.setGenero(livroAtualizado.getGenero());
            livro.setAnoPublicacao(livroAtualizado.getAnoPublicacao());
            livro.setPaginas(livroAtualizado.getPaginas());
            return repositorio.save(livro);
        }).orElseGet(() -> {
            livroAtualizado.setId(id);
            return repositorio.save(livroAtualizado);
        });
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        repositorio.deleteById(id);
    }

}
